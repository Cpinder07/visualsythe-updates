const KEYS = ["brightness", "contrast", "saturation", "hue", "night", "visibilitySaturation"];
const SECTIONS = {
  tone: ["brightness", "contrast"],
  palette: ["saturation", "hue"],
  night: ["night", "visibilitySaturation", "holo"],
};
const STYLES = [
  ["cross", "Cross"],
  ["dot", "Dot"],
  ["circle", "Circle"],
  ["crossdot", "Cross + dot"],
  ["t", "T-shape"],
  ["chevron", "Chevron"],
];

const state = {
  filters: {},
  baseline: {},
  baselineId: "custom",
  pinnedId: "",
  builtins: [],
  userProfiles: [],
  crosshair: {},
  autoApply: true,
  engineEnabled: true,
  hotkey: { vk: 0, label: "" },
  engineStatus: "",
  monitors: [],
  monitorId: "",
  quickres: {
    monitor: "",
    modes: [
      { id: "native", name: "Native", detail: "This monitor's normal size", available: true, active: true },
      { id: "1440x1080", name: "1440×1080", detail: "4:3 stretched", available: false, active: false },
      { id: "1280x960", name: "1280×960", detail: "4:3 stretched", available: false, active: false },
      { id: "1280x1024", name: "1280×1024", detail: "5:4 stretched", available: false, active: false },
      { id: "1024x768", name: "1024×768", detail: "4:3 stretched", available: false, active: false },
    ],
  },
  startWithWindows: true,
  applyWithGame: true,
  updateChannel: "stable",
  versionLabel: "Version 1.0.0",
  listening: false,
};

function $(id) { return document.getElementById(id); }

function api() {
  if (window.pywebview && window.pywebview.api) return window.pywebview.api;
  return null;
}

function formatValue(key, value) {
  const n = Number(value) || 0;
  if (key === "hue") {
    const rounded = Math.round(n);
    return rounded > 0 ? `+${rounded}` : String(rounded);
  }
  const text = n.toFixed(2);
  return key === "brightness" && n > 0 ? `+${text}` : text;
}

function sameFilters(a, b) {
  if (!a || !b) return false;
  for (const key of [...KEYS, "holo"]) {
    if (key === "holo") {
      if (Boolean(a.holo) !== Boolean(b.holo)) return false;
    } else if (Math.abs(Number(a[key]) - Number(b[key])) > 0.001) return false;
  }
  return true;
}

function profileName() {
  const all = [...state.builtins, ...state.userProfiles];
  const found = all.find((item) => item.id === state.baselineId);
  return found ? found.name : "Custom";
}

function applyState(next) {
  const pinned = state.pinnedId;
  Object.assign(state, next);
  const users = state.userProfiles || [];
  if (users.some((profile) => profile.id === state.baselineId)) state.pinnedId = state.baselineId;
  else if (state.baselineId && state.baselineId !== "custom") state.pinnedId = "";
  else state.pinnedId = pinned;
  paint();
}

function sameCross(a, b) {
  if (!b) return true;
  if (Boolean(a.enabled) !== Boolean(b.enabled) || a.style !== b.style || a.color !== b.color) return false;
  if (Boolean(a.centerDot) !== Boolean(b.centerDot)) return false;
  for (const key of ["size", "thickness", "gap", "opacity"]) {
    if (Math.abs(Number(a[key]) - Number(b[key])) > 0.001) return false;
  }
  return true;
}

function matchingPinned() {
  const pinned = (state.userProfiles || []).find((profile) => profile.id === state.pinnedId);
  if (!pinned || !sameFilters(state.filters, pinned.filters)) return null;
  if (pinned.crosshair && !sameCross(state.crosshair, pinned.crosshair)) return null;
  return pinned;
}

function syncPresetIdentity() {
  const match = matchingPinned();
  let nextId = "custom";
  if (match) nextId = match.id;
  else {
    const builtin = state.builtins.find((profile) => profile.id === state.baselineId && profile.id !== "custom");
    if (builtin && sameFilters(state.filters, builtin.filters)) nextId = builtin.id;
  }
  if (nextId === state.baselineId) return;
  state.baselineId = nextId;
  if (match) state.baseline = { ...match.filters };
  renderProfiles();
  renderPresets();
  const bridge = api();
  if (bridge) bridge.note_identity(nextId);
}

function paint() {
  for (const key of KEYS) {
    const input = $(key);
    const value = state.filters[key];
    input.value = value;
    $(`${key}Out`).textContent = formatValue(key, value);
    const num = document.querySelector(`[data-num="${key}"]`);
    num.value = key === "hue" ? Math.round(Number(value)) : Number(value).toFixed(2);
  }
  setSwitch($("holoSwitch"), Boolean(state.filters.holo));
  $("holoState").textContent = state.filters.holo ? "On" : "Off";
  setSwitch($("autoSwitch"), state.autoApply);
  setSwitch($("crossSwitch"), Boolean(state.crosshair.enabled));
  setSwitch($("dotSwitch"), Boolean(state.crosshair.centerDot));
  $("crossColor").value = state.crosshair.color || "#d7ff57";
  $("crossSize").value = state.crosshair.size;
  $("crossThick").value = state.crosshair.thickness;
  $("crossGap").value = state.crosshair.gap;
  $("crossOpacity").value = state.crosshair.opacity;
  $("applyBtn").hidden = state.autoApply;
  $("powerBtn").classList.toggle("on", state.engineEnabled);
  const pill = $("statusPill");
  pill.classList.toggle("off", !state.engineEnabled);
  $("statusLabel").textContent = state.engineEnabled ? "Active" : "Off";
  const matched = sameFilters(state.filters, state.baseline);
  $("footText").textContent = state.engineEnabled
    ? (matched ? `Preset ${profileName()} applied` : "Unsaved changes")
    : "Filters are off";
  $("engineNote").textContent = state.engineStatus || "Color engine idle.";
  setSwitch($("startupSwitch"), Boolean(state.startWithWindows));
  setSwitch($("gameSwitch"), Boolean(state.applyWithGame));
  setSwitch($("updateSwitch"), state.updateChannel === "beta");
  const version = $("versionLabel");
  if (version) version.textContent = state.versionLabel || "Version 1.0.0";
  renderMonitors();
  const bind = $("bindBtn");
  bind.textContent = state.listening ? "Press a key..." : (state.hotkey.label ? `Key ${state.hotkey.label}` : "Bind key");
  renderProfiles();
  renderPresets();
  renderQuickRes();
  renderStyles();
  drawPreview();
}

function setSwitch(button, on) {
  button.classList.toggle("on", on);
  button.setAttribute("aria-checked", on ? "true" : "false");
}

function renderProfiles() {
  const builtins = $("builtinList");
  builtins.replaceChildren();
  for (const profile of state.builtins) {
    if (profile.id === "custom") {
      const active = matchingPinned();
      const wrap = document.createElement("div");
      wrap.className = "custom-block";
      const button = document.createElement("button");
      button.type = "button";
      const selected = active ? state.baselineId === active.id : state.baselineId === "custom";
      button.className = "profile" + (selected ? " selected" : "");
      const thumb = document.createElement("span");
      const photo = active ? safeThumb(active.thumbnail) : "";
      thumb.className = "thumb " + (photo ? "photo" : "custom");
      if (photo) thumb.style.backgroundImage = `url("${photo}")`;
      const name = document.createElement("b");
      name.textContent = active ? active.name : "Custom";
      button.append(thumb, name);
      button.addEventListener("click", () => selectProfile(active || profile));
      const row = document.createElement("div");
      row.className = "custom-actions";
      const save = document.createElement("button");
      save.type = "button";
      save.className = "btn primary save-preset";
      save.textContent = "Save";
      save.addEventListener("click", () => openSaveDialog());
      const share = document.createElement("button");
      share.type = "button";
      share.className = "btn save-preset";
      share.textContent = "Share";
      share.addEventListener("click", () => shareCurrent());
      row.append(save, share);
      wrap.append(button, row);
      builtins.appendChild(wrap);
    } else {
      builtins.appendChild(profileButton(profile, true));
    }
  }
}

function safeThumb(value) {
  return typeof value === "string" && value.startsWith("data:image/") ? value : "";
}

function renderPresets() {
  const grid = $("presetGrid");
  grid.replaceChildren();
  if (!state.userProfiles.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "Nothing saved yet. Tune Custom on Filters, then press Save.";
    grid.appendChild(empty);
    return;
  }
  for (const profile of state.userProfiles) {
    const card = document.createElement("article");
    card.className = "preset-card" + (profile.id === state.baselineId ? " selected" : "");
    const open = document.createElement("button");
    open.type = "button";
    open.className = "preset-open";
    const thumb = safeThumb(profile.thumbnail);
    const shot = document.createElement(thumb ? "img" : "div");
    shot.className = "preset-shot";
    if (thumb) {
      shot.alt = "";
      shot.src = thumb;
    }
    const name = document.createElement("b");
    name.textContent = profile.name;
    open.append(shot, name);
    open.addEventListener("click", () => selectProfile(profile));
    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "ghost";
    remove.textContent = "×";
    remove.title = "Delete preset";
    remove.addEventListener("click", () => call(() => api().delete_profile(profile.id)));
    const share = document.createElement("button");
    share.type = "button";
    share.className = "text-btn preset-share";
    share.textContent = "Share";
    share.addEventListener("click", () => shareProfile(profile));
    card.append(open, share, remove);
    grid.appendChild(card);
  }
}

function profileButton(profile, builtin) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "profile" + (profile.id === state.baselineId ? " selected" : "");
  const thumb = document.createElement("span");
  thumb.className = "thumb " + (builtin ? profile.kind : "custom");
  const text = document.createElement("span");
  const name = document.createElement("b");
  name.textContent = profile.name;
  text.appendChild(name);
  button.append(thumb, text);
  button.addEventListener("click", () => selectProfile(profile));
  return button;
}

function renderStyles() {
  const list = $("styleList");
  list.replaceChildren();
  for (const [id, name] of STYLES) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "profile" + (state.crosshair.style === id ? " selected" : "");
    const thumb = document.createElement("span");
    thumb.className = "thumb custom";
    const label = document.createElement("b");
    label.textContent = name;
    button.append(thumb, label);
    button.addEventListener("click", () => {
      state.crosshair.style = id;
      paint();
      call(() => api().set_crosshair(state.crosshair));
    });
    list.appendChild(button);
  }
}

async function call(fn) {
  const bridge = api();
  if (!bridge) {
    paint();
    return;
  }
  const next = await fn();
  if (next && next.filters) applyState(next);
}

function pushFilters(applyNow) {
  const bridge = api();
  if (!bridge) {
    paint();
    return;
  }
  clearTimeout(pushFilters.timer);
  pushFilters.timer = setTimeout(() => {
    bridge.set_filters({ ...state.filters }, Boolean(applyNow || state.autoApply));
  }, 30);
}

function selectProfile(profile) {
  state.pinnedId = (state.userProfiles || []).some((item) => item.id === profile.id) ? profile.id : "";
  state.baselineId = profile.id;
  state.baseline = { ...profile.filters };
  state.filters = { ...profile.filters };
  if (profile.crosshair) state.crosshair = { ...state.crosshair, ...profile.crosshair };
  call(async () => {
    if (profile.crosshair) await api().set_crosshair(state.crosshair);
    return api().remember_baseline(profile.id, profile.filters);
  });
}

function resetKey(key) {
  if (key === "holo") state.filters.holo = Boolean(state.baseline.holo);
  else state.filters[key] = state.baseline[key];
  syncPresetIdentity();
  paint();
  pushFilters(false);
}

function drawPreview() {
  const canvas = $("preview");
  const ctx = canvas.getContext("2d");
  const w = canvas.width;
  const h = canvas.height;
  const sky = ctx.createLinearGradient(0, 0, 0, h);
  sky.addColorStop(0, "#8ec6ef");
  sky.addColorStop(0.45, "#d7efe4");
  sky.addColorStop(1, "#6d8f62");
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, w / 2, h);
  ctx.fillStyle = "#1b2430";
  ctx.fillRect(w / 2, 0, w / 2, h);
  ctx.fillStyle = "#f4f7fb";
  ctx.fillRect(w / 2, 0, w / 2, h * 0.42);
  const cx = w / 2;
  const cy = h / 2;
  const ch = state.crosshair;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.strokeStyle = ch.color || "#d7ff57";
  ctx.fillStyle = ch.color || "#d7ff57";
  ctx.globalAlpha = Number(ch.opacity) || 1;
  ctx.lineWidth = Number(ch.thickness) || 2;
  const arm = Number(ch.size) || 10;
  const gap = Number(ch.gap) || 0;
  if (ch.enabled && (ch.style === "cross" || ch.style === "crossdot" || ch.style === "t")) {
    ctx.beginPath();
    ctx.moveTo(-gap - arm, 0); ctx.lineTo(-gap, 0);
    ctx.moveTo(gap, 0); ctx.lineTo(gap + arm, 0);
    ctx.stroke();
  }
  if (ch.enabled && (ch.style === "cross" || ch.style === "crossdot")) {
    ctx.beginPath();
    ctx.moveTo(0, -gap - arm); ctx.lineTo(0, -gap);
    ctx.moveTo(0, gap); ctx.lineTo(0, gap + arm);
    ctx.stroke();
  }
  if (ch.enabled && ch.style === "t") {
    ctx.beginPath();
    ctx.moveTo(0, gap); ctx.lineTo(0, gap + arm);
    ctx.stroke();
  }
  if (ch.enabled && ch.style === "dot") {
    ctx.beginPath();
    ctx.arc(0, 0, Math.max(2, Number(ch.thickness)), 0, Math.PI * 2);
    ctx.fill();
  }
  if (ch.enabled && ch.style === "circle") {
    ctx.beginPath();
    ctx.arc(0, 0, arm, 0, Math.PI * 2);
    ctx.stroke();
  }
  if (ch.enabled && ch.style === "chevron") {
    ctx.beginPath();
    ctx.moveTo(-gap - arm, gap + arm); ctx.lineTo(-gap, gap);
    ctx.lineTo(gap, gap); ctx.lineTo(gap + arm, gap + arm);
    ctx.stroke();
  }
  if (ch.enabled && ch.centerDot && ch.style !== "dot") {
    ctx.beginPath();
    ctx.arc(0, 0, 2, 0, Math.PI * 2);
    ctx.fill();
  }
  if (state.filters.holo) {
    ctx.globalAlpha = 0.9;
    ctx.strokeStyle = "#111";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(0, 0, 24, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
}

function renderMonitors() {
  const select = $("monitorSelect");
  if (!select) return;
  const chosen = state.monitorId;
  select.replaceChildren();
  for (const monitor of state.monitors || []) {
    const option = document.createElement("option");
    option.value = monitor.id;
    option.textContent = monitor.label;
    select.appendChild(option);
  }
  if (chosen && [...select.options].some((option) => option.value === chosen)) {
    select.value = chosen;
  }
}

function pushSettings() {
  const bridge = api();
  if (!bridge) return;
  call(() => bridge.set_settings({
    monitorId: state.monitorId,
    startWithWindows: state.startWithWindows,
    applyWithGame: state.applyWithGame,
    updateChannel: state.updateChannel,
  }));
}

function renderQuickRes() {
  const grid = $("quickresGrid");
  if (!grid) return;
  const info = state.quickres || { modes: [] };
  const label = $("quickresMonitor");
  if (label) label.textContent = info.monitor || "Uses the monitor chosen in Settings.";
  grid.replaceChildren();
  for (const mode of info.modes || []) {
    const card = document.createElement("button");
    card.type = "button";
    card.className = "res-card" + (mode.active ? " selected" : "");
    card.disabled = mode.available === false;
    const name = document.createElement("b");
    name.textContent = mode.name;
    const detail = document.createElement("span");
    detail.textContent = mode.detail || "";
    card.append(name, detail);
    card.addEventListener("click", () => pickResolution(mode.id));
    grid.appendChild(card);
  }
}

async function pickResolution(modeId) {
  const bridge = api();
  if (!bridge) return;
  const next = await bridge.apply_resolution(modeId);
  if (next && next.filters) applyState(next);
  if (next && next.message) $("footText").textContent = next.message;
  else if (next && next.ok) $("footText").textContent = "Resolution applied";
}

function showTab(name) {
  const views = {
    filters: "filtersView",
    presets: "presetsView",
    crosshairs: "crossView",
    quickres: "quickresView",
    settings: "settingsView",
  };
  document.querySelectorAll(".tab").forEach((tab) => tab.classList.toggle("active", tab.dataset.tab === name));
  for (const [key, id] of Object.entries(views)) {
    const view = $(id);
    const on = key === name;
    view.classList.toggle("active", on);
    view.inert = !on;
  }
  if (name === "crosshairs") drawPreview();
}

function onSlider(key, raw) {
  const value = key === "hue" ? Math.round(Number(raw)) : Number(raw);
  state.filters[key] = value;
  $(`${key}Out`).textContent = formatValue(key, value);
  const num = document.querySelector(`[data-num="${key}"]`);
  if (document.activeElement !== num) {
    num.value = key === "hue" ? value : value.toFixed(2);
  }
  $("footText").textContent = state.engineEnabled ? "Unsaved changes" : "Filters are off";
  syncPresetIdentity();
  if (state.autoApply) pushFilters(true);
}

document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => showTab(tab.dataset.tab));
});

for (const key of KEYS) {
  $(key).addEventListener("input", (event) => onSlider(key, event.target.value));
  document.querySelector(`[data-num="${key}"]`).addEventListener("change", (event) => {
    onSlider(key, event.target.value);
    paint();
  });
}

document.querySelectorAll("[data-reset]").forEach((button) => {
  button.addEventListener("click", () => {
    for (const key of SECTIONS[button.dataset.reset]) resetKey(key);
  });
});
document.querySelectorAll("[data-reset-key]").forEach((button) => {
  button.addEventListener("click", () => resetKey(button.dataset.resetKey));
});

$("holoSwitch").addEventListener("click", () => {
  state.filters.holo = !state.filters.holo;
  syncPresetIdentity();
  paint();
  pushFilters(true);
});
$("autoSwitch").addEventListener("click", () => {
  state.autoApply = !state.autoApply;
  paint();
  call(() => api().set_options(state.autoApply, state.engineEnabled));
});
$("powerBtn").addEventListener("click", () => {
  state.engineEnabled = !state.engineEnabled;
  paint();
  call(() => api().set_options(state.autoApply, state.engineEnabled));
});
$("applyBtn").addEventListener("click", () => pushFilters(true));
$("resetBtn").addEventListener("click", () => {
  state.filters = { ...state.baseline };
  syncPresetIdentity();
  paint();
  pushFilters(false);
});
let pendingThumb = "";

function paintThumbPreview() {
  const preview = $("thumbPreview");
  preview.style.backgroundImage = pendingThumb ? `url("${pendingThumb}")` : "";
}

function openSaveDialog() {
  pendingThumb = "";
  $("profileName").value = "";
  $("thumbFile").value = "";
  paintThumbPreview();
  $("modal").inert = false;
  $("modal").classList.add("open");
  $("profileName").focus();
}

function closeSaveDialog() {
  $("modal").classList.remove("open");
  $("modal").inert = true;
}

function shrinkImage(file) {
  return new Promise((resolve) => {
    const image = new Image();
    const url = URL.createObjectURL(file);
    image.onload = () => {
      const scale = Math.min(1, 320 / image.width, 180 / image.height);
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(image.width * scale));
      canvas.height = Math.max(1, Math.round(image.height * scale));
      canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/jpeg", 0.72));
    };
    image.onerror = () => {
      URL.revokeObjectURL(url);
      resolve("");
    };
    image.src = url;
  });
}

$("createBtn").addEventListener("click", () => openSaveDialog());
$("cancelProfile").addEventListener("click", () => closeSaveDialog());
$("modal").addEventListener("click", (event) => {
  if (event.target === $("modal")) closeSaveDialog();
});
$("clearThumb").addEventListener("click", () => {
  pendingThumb = "";
  $("thumbFile").value = "";
  paintThumbPreview();
});
$("thumbFile").addEventListener("change", async (event) => {
  const file = event.target.files && event.target.files[0];
  pendingThumb = file ? await shrinkImage(file) : "";
  if (pendingThumb.length > 180000) pendingThumb = "";
  paintThumbPreview();
});
$("profileForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const name = $("profileName").value.trim();
  if (!name) return;
  const thumbnail = pendingThumb;
  closeSaveDialog();
  call(() => api().create_profile(name, thumbnail));
});
$("bindBtn").addEventListener("click", () => {
  state.listening = !state.listening;
  paint();
});
window.addEventListener("keydown", (event) => {
  if (!state.listening) return;
  event.preventDefault();
  if (event.code === "Escape") {
    state.listening = false;
    paint();
    return;
  }
  const vk = codeToVk(event);
  if (!vk) return;
  state.listening = false;
  state.hotkey = { vk, label: event.code.replace(/^Key/, "").replace(/^Digit/, "") };
  paint();
  call(() => api().set_hotkey(vk, state.hotkey.label));
});

function codeToVk(event) {
  if (event.code.startsWith("Key")) return event.code.charCodeAt(3);
  if (event.code.startsWith("Digit")) return 0x30 + Number(event.code.slice(5));
  const fn = /^F(\d+)$/.exec(event.code);
  if (fn) {
    const n = Number(fn[1]);
    if (n >= 1 && n <= 24) return 0x70 + n - 1;
  }
  const named = {
    Space: 0x20, Minus: 0xbd, Equal: 0xbb, BracketLeft: 0xdb, BracketRight: 0xdd,
    Backslash: 0xdc, Semicolon: 0xba, Quote: 0xde, Comma: 0xbc, Period: 0xbe,
    Slash: 0xbf, Backquote: 0xc0, Insert: 0x2d, Delete: 0x2e, Home: 0x24, End: 0x23,
    PageUp: 0x21, PageDown: 0x22, ArrowLeft: 0x25, ArrowUp: 0x26, ArrowRight: 0x27, ArrowDown: 0x28,
  };
  return named[event.code] || 0;
}

$("crossSwitch").addEventListener("click", () => updateCross({ enabled: !state.crosshair.enabled }));
$("dotSwitch").addEventListener("click", () => updateCross({ centerDot: !state.crosshair.centerDot }));
$("crossColor").addEventListener("input", (event) => updateCross({ color: event.target.value }));
$("crossSize").addEventListener("input", (event) => updateCross({ size: Number(event.target.value) }));
$("crossThick").addEventListener("input", (event) => updateCross({ thickness: Number(event.target.value) }));
$("crossGap").addEventListener("input", (event) => updateCross({ gap: Number(event.target.value) }));
$("crossOpacity").addEventListener("input", (event) => updateCross({ opacity: Number(event.target.value) }));

function updateCross(patch) {
  state.crosshair = { ...state.crosshair, ...patch };
  syncPresetIdentity();
  paint();
  call(() => api().set_crosshair(state.crosshair));
}

function currentSharePayload() {
  const active = matchingPinned();
  if (active) {
    return {
      name: active.name,
      thumbnail: active.thumbnail || "",
      filters: { ...active.filters },
      crosshair: { ...(active.crosshair || state.crosshair) },
    };
  }
  const builtin = state.builtins.find((profile) => profile.id === state.baselineId && profile.id !== "custom");
  if (builtin && sameFilters(state.filters, builtin.filters)) {
    return { name: builtin.name, thumbnail: "", filters: { ...state.filters }, crosshair: { ...state.crosshair } };
  }
  return { name: "Custom preset", thumbnail: "", filters: { ...state.filters }, crosshair: { ...state.crosshair } };
}

async function sharePayload(payload) {
  const bridge = api();
  if (!bridge) return;
  const result = await bridge.share_preset(payload);
  if (result && result.ok) $("footText").textContent = "Preset saved to send";
  else if (result && result.message) $("footText").textContent = result.message;
}

function shareCurrent() {
  sharePayload(currentSharePayload());
}

function shareProfile(profile) {
  sharePayload({
    name: profile.name || "Custom preset",
    thumbnail: profile.thumbnail || "",
    filters: { ...profile.filters },
    crosshair: { ...(profile.crosshair || state.crosshair) },
  });
}

$("importBtn").addEventListener("click", async () => {
  const bridge = api();
  if (!bridge) return;
  const next = await bridge.import_profiles();
  if (next && next.filters) applyState(next);
  else if (next && next.message) $("footText").textContent = next.message;
});
$("exportBtn").addEventListener("click", async () => {
  const bridge = api();
  if (!bridge) return;
  await bridge.export_profiles();
});
document.querySelector(".app").addEventListener("mousedown", (event) => {
  if (event.target.closest("input, button, textarea, select, a, label")) {
    event.stopPropagation();
  }
});
$("monitorSelect").addEventListener("change", (event) => {
  state.monitorId = event.target.value;
  pushSettings();
});
$("startupSwitch").addEventListener("click", () => {
  state.startWithWindows = !state.startWithWindows;
  paint();
  pushSettings();
});
$("gameSwitch").addEventListener("click", () => {
  state.applyWithGame = !state.applyWithGame;
  paint();
  pushSettings();
});
$("updateSwitch").addEventListener("click", () => {
  state.updateChannel = state.updateChannel === "beta" ? "stable" : "beta";
  paint();
  pushSettings();
});

async function boot() {
  const bridge = api();
  if (!bridge) return;
  applyState(await bridge.get_state());
  window.setInterval(async () => {
    const beat = await bridge.poll();
    if (!beat) return;
    if (beat.engineEnabled !== state.engineEnabled) {
      state.engineEnabled = beat.engineEnabled;
      state.engineStatus = beat.engineStatus;
      paint();
    } else if (beat.engineStatus !== state.engineStatus) {
      state.engineStatus = beat.engineStatus;
      $("engineNote").textContent = beat.engineStatus || "Color engine idle.";
    }
  }, 400);
}

const NEUTRAL = {
  brightness: 0, contrast: 1, saturation: 1, hue: 0, night: 0, visibilitySaturation: 1, holo: false,
};
state.filters = { ...NEUTRAL };
state.baseline = { ...NEUTRAL };
state.crosshair = { enabled: false, style: "cross", color: "#d7ff57", size: 10, thickness: 2, gap: 4, opacity: 0.95, centerDot: true };
state.builtins = [
  { id: "custom", name: "Custom", kind: "custom", filters: { ...NEUTRAL } },
  { id: "summer", name: "Summer", kind: "summer", filters: { ...NEUTRAL, brightness: 0.04, contrast: 1.06, saturation: 1.28, hue: 12, visibilitySaturation: 1.08 } },
  { id: "winter", name: "Winter", kind: "winter", filters: { ...NEUTRAL, brightness: 0.06, contrast: 1.14, saturation: 0.82, hue: -16, night: 0.25, visibilitySaturation: 0.95 } },
  { id: "desert", name: "Desert", kind: "desert", filters: { ...NEUTRAL, brightness: 0.05, contrast: 1.2, saturation: 1.08, hue: 22 } },
  { id: "night", name: "Night Vision", kind: "night", filters: { ...NEUTRAL, brightness: 0.04, contrast: 1.18, saturation: 1.4, hue: -14, night: 1.85, visibilitySaturation: 1.2 } },
];
paint();

window.addEventListener("pywebviewready", () => {
  window.__vsReady = true;
  boot();
});
if (window.pywebview && window.pywebview.api) boot();
